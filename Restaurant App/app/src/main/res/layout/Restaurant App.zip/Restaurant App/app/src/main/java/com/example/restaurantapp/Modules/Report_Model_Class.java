package com.example.restaurantapp.Modules;

public class Report_Model_Class {

    public int report_id;
    public String report_name;
    public int report_number;

    public Report_Model_Class(int report_id, String report_name, int report_number) {
        this.report_id  = report_id;
        this.report_name = report_name;
        this.report_number = report_number;
    }
}
