package com.example.restaurantapp.Modules;

public class Dash_Model_Class {

    public int id,price,number;
    public String dash_name;

    public Dash_Model_Class(int id, int price, int number, String name) {
        this.id = id;
        this.price = price;
        this.number = number;
        this.dash_name = name;
    }
}
