package com.example.restaurantapp.Modules;

public class DataModel {
 public int id;
 public String name;

    public DataModel(int id, String name) {
        this.id = id;
        this.name = name;
    }
}
